//
//  RegionViewController.swift
//  WeatherToday
//
//  Created by 박제균 on 2022/01/26.
//

/* Todo
 - 화면2: 도시 목록 [x]
 - 네비게이션 타이틀 [x]
 - 테이블뷰 구성 [x]
 - 날씨에 맞는 이미지 [x]
 - 이미지 오른쪽에 도시명, 온도, 강수확률
 - 액세서리뷰 표시 [x]
 */

import UIKit


class CityViewController: UIViewController {

    @IBOutlet weak var cityTableView: UITableView!

    let cityCellIdentifier: String = "cityCell"
    var country: Country?
    var cities: [City] = []

    override func viewDidLoad() {
        super.viewDidLoad()

        guard let countryKoreanName: String = country?.koreanName else {
            return
        }
        guard let countryAssetName: String = country?.assetName else {
            return
        }

        self.navigationItem.title = "\(countryKoreanName)"

        // MARK: - Decode JSON
        let jsonDecoder: JSONDecoder = JSONDecoder()

        guard let countryAsset: NSDataAsset = NSDataAsset(name: "\(countryAssetName)") else {
            return
        }

        do {
            self.cities = try jsonDecoder.decode([City].self, from: countryAsset.data)
        } catch {
            print(error.localizedDescription)
        }

        self.cityTableView.reloadData()
    }
}

// MARK: - TableView

extension CityViewController: UITableViewDataSource, UITableViewDelegate {

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.cities.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell: CityTableViewCell = cityTableView.dequeueReusableCell(withIdentifier: cityCellIdentifier, for: indexPath)
        as! CityTableViewCell

        let city: City = self.cities[indexPath.row]
        
        cell.weatherImageView.image = UIImage(named: city.weather)
        cell.cityNameLabel.text = city.cityName
        cell.temperatureLabel.text = city.temperatureString
        cell.rainFallProbabilityLabel.text = city.rainFallProbabilityString
        if city.rainFallProbability > 50 { cell.rainFallProbabilityLabel.textColor = .orange }
        if city.celsius < 10 { cell.temperatureLabel.textColor = .blue }

        return cell
    }
    
    
    // 셀 선택시 화면3으로 이동, 화면3에 객체 전달.
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     
        guard let detailViewController: DetailViewController = segue.destination as? DetailViewController else {
            return
        }
        
        guard let cell: CityTableViewCell = sender as? CityTableViewCell else {
            return
        }
        
        let city = self.cities.filter { $0.cityName == cell.cityNameLabel.text }[0]
        
        detailViewController.cityWeatherInformation = city
        
    }
}
