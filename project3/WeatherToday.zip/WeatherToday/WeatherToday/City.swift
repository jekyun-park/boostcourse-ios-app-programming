//
//  City.swift
//  WeatherToday
//
//  Created by 박제균 on 2022/01/26.
//

/* {
 "city_name":"베를린",
 "state":12,
 "celsius":10.8,
 "rainfall_probability":60
 },
 */

import Foundation

// MARK: - 도시 정보
struct City: Codable {
    
    let cityName: String
    let state: Int
    let celsius: Double
    let rainFallProbability: Int
    
    var weather : String {
        var string: String = ""
        if self.state == 10 {
            string = "sunny"
        } else if self.state == 11 {
            string = "cloudy"
        } else if self.state == 12 {
            string = "rainy"
        } else if self.state == 13 {
            string = "snowy"}
        return string
    }
    
    var koreanWeather: String {
        var string: String = ""
        if self.weather == "sunny" {
            string = "맑음"
        } else if self.weather == "cloudy" {
            string = "구름"
        } else if self.weather == "rainy" {
            string = "비"
        } else if self.weather == "snowy" {
            string = "눈"}
        return string
    }
    
    var fahrenheit : Double {
        return (self.celsius * 1.8 + 32)
    }
    
    var temperatureString: String {
        let fahrenheitString: String = String(format: "%.1f", self.fahrenheit)
        return "섭씨 \(self.celsius)도 / 화씨 \(fahrenheitString)도"
    }
    
    var rainFallProbabilityString: String {
        return "강수확률 \(self.rainFallProbability)%"
    }
    
    enum CodingKeys: String, CodingKey {
        case state, celsius
        case cityName = "city_name"
        case rainFallProbability = "rainfall_probability"
    }
}
